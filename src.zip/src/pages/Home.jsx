import Header from "../components/Header"
import EgliseCard from "../components/EgliseCard"
import eglises from "../data/eglises"
import { useState } from "react"

export default function Home() {
    const [paysSelectionne, setPaysSelectionne] = useState("Tous")
  return (
    <div className="min-h-screen bg-stone-100">
      <Header />

      <main className="mx-auto max-w-7xl p-10">
        <h2 className="mb-8 text-6xl font-semibold tracking-wide"
    style={{ fontFamily: "Bookman Old Style, serif" }}>
          Découvrez votre collection d'églises
        </h2>
<select
  value={paysSelectionne}
  onChange={(e) => setPaysSelectionne(e.target.value)}
  className="mb-8 rounded-full border border-[#E8D5EF] bg-white px-5 py-3 shadow-md transition-all duration-300 hover:border-[#CA7CDF] focus:border-[#CA7CDF] focus:outline-none"
>
  <option>Tous</option>

  {[...new Set(eglises.map((eglise) => eglise.pays))]
    .sort()
    .map((pays) => (
      <option key={pays}>
        {pays}
      </option>
    ))}
</select>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {eglises
  .filter(
    (eglise) =>
      paysSelectionne === "Tous" ||
      eglise.pays === paysSelectionne
  )
  .map((eglise) => (
            <EgliseCard
              key={eglise.id}
              eglise={eglise}
            />
          ))}
        </div>
      </main>
    </div>
  )
}