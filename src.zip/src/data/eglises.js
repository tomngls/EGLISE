const eglises = [
  {
  id: "notre-dame-de-paris",
  nom: "Notre-Dame de Paris",
  ville: "Paris",
  pays: "France",
  latitude: 48.852968,
  longitude: 2.349902,

  dossier: "notre-dame-paris",
  nbPhotos: 14,
},

  {
  id: "eglise-saint-peter-et-paul-port-glaud",
  nom: "Église Saint Peter et Paul",
  ville: "Port Glaud",
  pays: "Seychelles",
  latitude: -4.659407,
  longitude: 55.410581,

  dossier: "eglise-saint-peter-et-paul-port-glaud-seychelles",
  nbPhotos: 2,
},
]

export default eglises