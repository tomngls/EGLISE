import { genererPhotos } from "../utils/photo"

export default function PhotoViewer({
  photoOuverte,
  setPhotoOuverte,
  eglise,
  photoActive,
  setPhotoActive,
}) {
  if (!photoOuverte) return null
  const photos = genererPhotos(
  eglise.dossier,
  eglise.nbPhotos
)
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-sm animate-fade"
      onClick={() => setPhotoOuverte(false)}
    >
      <button
        onClick={() => setPhotoOuverte(false)}
        className="absolute right-6 top-6 flex h-12 w-12 items-center justify-center rounded-full bg-[#CA7CDF]/85 text-3xl text-white backdrop-blur-sm transition duration-200 hover:scale-110 hover:bg-[#B765D3]"
      >
        ✕
      </button>

      <button
        onClick={(e) => {
          e.stopPropagation()
          setPhotoActive(
            photoActive === 0
              ? photos.length - 1
              : photoActive - 1
          )
        }}
        className="absolute left-6 flex h-14 w-14 items-center justify-center rounded-full bg-[#CA7CDF]/85 text-4xl text-white backdrop-blur-sm transition duration-200 hover:scale-110 hover:bg-[#B765D3]"

      >
        ‹
      </button>

      <img
        src={photos[photoActive]}
        alt={eglise.nom}
        className="max-h-[90vh] max-w-[90vw] rounded-2xl shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      />

      <div className="absolute bottom-6 right-6 text-xl font-semibold text-white">
        {photoActive + 1} / {photos.length}
      </div>

      <button
        onClick={(e) => {
          e.stopPropagation()
          setPhotoActive(
            photoActive === photos.length - 1
              ? 0
              : photoActive + 1
          )
        }}
        className="absolute right-6 flex h-14 w-14 items-center justify-center rounded-full bg-[#CA7CDF]/85 text-4xl text-white backdrop-blur-sm transition duration-200 hover:scale-110 hover:bg-[#B765D3]"
      >
        ›
      </button>
    </div>
  )
}