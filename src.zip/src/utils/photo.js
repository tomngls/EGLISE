export function genererPhotos(dossier, nbPhotos) {
  return Array.from(
    { length: nbPhotos },
    (_, i) =>
      `/images/${dossier}/${String(i + 1).padStart(2, "0")}.jpeg`
  )
}